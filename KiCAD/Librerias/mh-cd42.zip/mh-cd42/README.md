# mh-cd42

Modelo 3d

![modelo3d](./grabcad/mh-cd42.png)


Johnny
