https://grabcad.com/library/mh-cd42-tp5306-based-charge-5v-boost-board-1
