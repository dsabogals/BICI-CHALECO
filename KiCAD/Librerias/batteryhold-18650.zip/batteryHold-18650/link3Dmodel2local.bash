ln -sr ./grabcad/Hold_18650-1p_smd.stp $HOME/.local/share/kicad/6.0/3dmodels
