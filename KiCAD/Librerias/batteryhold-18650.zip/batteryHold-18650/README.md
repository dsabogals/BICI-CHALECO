# battery 18650

https://kicad.github.io/footprints/Battery

Modelo 3d

![Modelo 3D](./grabcad/hold-18650.png)


